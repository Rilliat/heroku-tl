# Versions should comply with PEP440.
# This line is parsed in setup.py:
__version__ = '2.5.0'
telethon_upstream = '1.28.5'
